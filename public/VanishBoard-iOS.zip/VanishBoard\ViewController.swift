﻿import UIKit
import WebKit
import WidgetKit

class ViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler, WKUIDelegate {

    private var webView: WKWebView!
    private let appGroupName = "group.com.vanishboard.app"

    override var prefersStatusBarHidden: Bool {
        return true
    }

    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupWebView()
        loadWebContent()
    }

    private func setupWebView() {
        let contentController = WKUserContentController()

        // Polyfill bridge so existing AndroidBridge calls seamlessly dispatch to iOS native
        let bridgeScriptSource = """
        if (!window.AndroidBridge) {
            window.AndroidBridge = {
                updateWidgetStrokes: function(json) {
                    try { window.webkit.messageHandlers.iosBridge.postMessage({ action: 'updateWidgetStrokes', strokes: json }); } catch(e){}
                },
                updateWidgetPreview: function(base64) {
                    try { window.webkit.messageHandlers.iosBridge.postMessage({ action: 'updateWidgetPreview', preview: base64 }); } catch(e){}
                },
                updateRoomInfo: function(roomCode, userCount) {
                    try { window.webkit.messageHandlers.iosBridge.postMessage({ action: 'updateRoomInfo', roomCode: roomCode, userCount: userCount }); } catch(e){}
                },
                setServerUrl: function(url) {
                    try { window.webkit.messageHandlers.iosBridge.postMessage({ action: 'setServerUrl', serverUrl: url }); } catch(e){}
                }
            };
        }
        """
        let bridgeScript = WKUserScript(source: bridgeScriptSource, injectionTime: .atDocumentStart, forMainFrameOnly: false)
        contentController.addUserScript(bridgeScript)
        contentController.add(self, name: "iosBridge")

        let config = WKWebViewConfiguration()
        config.userContentController = contentController
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.backgroundColor = UIColor(red: 0.996, green: 0.976, blue: 0.765, alpha: 1.0)
        webView.isOpaque = true

        // Disable scrolling and bounce for rock-solid drawing experience
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never

        view.addSubview(webView)
    }

    private func loadWebContent() {
        // Load bundled web assets if present, otherwise live Render cloud host
        if let bundleUrl = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "www") {
            webView.loadFileURL(bundleUrl, allowingReadAccessTo: bundleUrl.deletingLastPathComponent())
        } else if let cloudUrl = URL(string: "https://vanishboard.onrender.com") {
            let request = URLRequest(url: cloudUrl, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 15.0)
            webView.load(request)
        }
    }

    // MARK: - WKScriptMessageHandler
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "iosBridge", let dict = message.body as? [String: Any], let action = dict["action"] as? String else {
            return
        }

        let defaults = UserDefaults(suiteName: appGroupName) ?? UserDefaults.standard

        switch action {
        case "updateRoomInfo":
            if let roomCode = dict["roomCode"] as? String {
                defaults.set(roomCode, forKey: "active_room")
            }
            if let userCount = dict["userCount"] as? Int {
                defaults.set(userCount, forKey: "user_count")
            }
            WidgetCenter.shared.reloadAllTimelines()

        case "setServerUrl":
            if let serverUrl = dict["serverUrl"] as? String {
                defaults.set(serverUrl, forKey: "server_url")
            }

        case "updateWidgetPreview":
            if let previewBase64 = dict["preview"] as? String {
                saveWidgetPreviewImage(previewBase64)
                WidgetCenter.shared.reloadAllTimelines()
            }

        case "updateWidgetStrokes":
            if let strokes = dict["strokes"] as? String {
                defaults.set(strokes, forKey: "cached_strokes")
                WidgetCenter.shared.reloadAllTimelines()
            }

        default:
            break
        }
    }

    private func saveWidgetPreviewImage(_ base64String: String) {
        var cleanBase64 = base64String
        if let commaIndex = cleanBase64.firstIndex(of: ",") {
            cleanBase64 = String(cleanBase64[cleanBase64.index(after: commaIndex)...])
        }
        guard let data = Data(base64Encoded: cleanBase64) else { return }

        let defaults = UserDefaults(suiteName: appGroupName) ?? UserDefaults.standard
        defaults.set(data, forKey: "widget_preview_image")

        if let containerUrl = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupName) {
            let fileUrl = containerUrl.appendingPathComponent("widget_preview.png")
            try? data.write(to: fileUrl)
        }
    }
}
