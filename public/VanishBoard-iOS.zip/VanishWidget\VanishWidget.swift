﻿import WidgetKit
import SwiftUI

struct Provider: TimelineProvider {
    let appGroupName = "group.com.vanishboard.app"

    func placeholder(in context: Context) -> VanishEntry {
        VanishEntry(date: Date(), roomCode: "DEMO-99", userCount: 2, previewImage: nil)
    }

    func getSnapshot(in context: Context, completion: @escaping (VanishEntry) -> Void) {
        let entry = currentEntry()
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<Entry>) -> Void) {
        let entry = currentEntry()
        // Refresh every 5 minutes automatically, plus instant updates triggered by the main app
        let nextUpdate = Calendar.current.date(byAdding: .minute, value: 5, to: Date())!
        let timeline = Timeline(entries: [entry], policy: .after(nextUpdate))
        completion(timeline)
    }

    private func currentEntry() -> VanishEntry {
        let defaults = UserDefaults(suiteName: appGroupName) ?? UserDefaults.standard
        let roomCode = defaults.string(forKey: "active_room") ?? "NO ROOM"
        let userCount = defaults.integer(forKey: "user_count")

        var image: UIImage? = nil
        if let data = defaults.data(forKey: "widget_preview_image") {
            image = UIImage(data: data)
        } else if let containerUrl = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupName) {
            let fileUrl = containerUrl.appendingPathComponent("widget_preview.png")
            if let fileData = try? Data(contentsOf: fileUrl) {
                image = UIImage(data: fileData)
            }
        }

        return VanishEntry(
            date: Date(),
            roomCode: roomCode,
            userCount: max(1, userCount),
            previewImage: image
        )
    }
}

struct VanishEntry: TimelineEntry {
    let date: Date
    let roomCode: String
    let userCount: Int
    let previewImage: UIImage?
}

struct VanishWidgetEntryView : View {
    var entry: Provider.Entry
    @Environment(\.widgetFamily) var family

    var body: some View {
        ZStack {
            // Sticky Note Yellow Background
            LinearGradient(
                gradient: Gradient(colors: [Color(red: 0.996, green: 0.941, blue: 0.541), Color(red: 0.992, green: 0.878, blue: 0.278)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            // Top sticky tape sticker
            VStack {
                Rectangle()
                    .fill(Color.white.opacity(0.35))
                    .frame(width: 54, height: 10)
                    .cornerRadius(2)
                    .padding(.top, 4)
                Spacer()
            }

            VStack(spacing: 4) {
                // Header badge: Room Code & Users Count
                HStack {
                    HStack(spacing: 3) {
                        Text("ROOM")
                            .font(.system(size: 8, weight: .black))
                            .foregroundColor(Color.black.opacity(0.5))
                        Text(entry.roomCode)
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundColor(Color(red: 0.09, green: 0.09, blue: 0.11))
                    }
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Color.white.opacity(0.55))
                    .cornerRadius(6)

                    Spacer()

                    HStack(spacing: 3) {
                        Circle()
                            .fill(Color.green)
                            .frame(width: 6, height: 6)
                        Text("\(entry.userCount)")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(Color.black.opacity(0.75))
                    }
                }
                .padding(.horizontal, 8)
                .padding(.top, 14)

                // Canvas Drawing Preview
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color(red: 0.996, green: 0.976, blue: 0.765))
                        .shadow(color: Color.black.opacity(0.08), radius: 2, x: 0, y: 1)

                    if let img = entry.previewImage {
                        Image(uiImage: img)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    } else {
                        VStack(spacing: 4) {
                            Image(systemName: "pencil.and.outline")
                                .font(.system(size: 20))
                                .foregroundColor(Color.black.opacity(0.3))
                            Text("Empty Canvas")
                                .font(.system(size: 9, weight: .medium))
                                .foregroundColor(Color.black.opacity(0.4))
                        }
                    }
                }
                .padding(.horizontal, 8)
                .padding(.bottom, 6)
            }
        }
        .widgetURL(URL(string: "vanishboard://open"))
    }
}

@main
struct VanishWidget: Widget {
    let kind: String = "VanishWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            VanishWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("VanishBoard Sticky")
        .description("Live collaborative sticky note canvas.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}
